<?php
// Silence is golden
?>